SASS compiling, see here: https://medium.com/@brianhan/watch-compile-your-sass-with-npm-9ba2b878415b#.mzd9cakla


// start in terminal with
// npm run watch-css
