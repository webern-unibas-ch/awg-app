var s=class{constructor(i,l,t,h){this.root=i,this.link=l,this.label=t,this.disabled=h}};export{s as a};
