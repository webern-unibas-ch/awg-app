var r;(function(t){t.GRAPH="graph",t.GRID="grid",t.TABLE="table"})(r||(r={}));var o=class{constructor(c,s,h){this.label=c,this.type=s,this.icon=h}};export{r as a,o as b};
